<?php 
/**
*  Geetest配置文件
* @author Tanxu
*/
define("CAPTCHA_ID", "48a6ebac4ebc6642d68c217fca33eb4d");
define("PRIVATE_KEY", "4f1c085290bec5afdc54df73535fc361");



 ?>