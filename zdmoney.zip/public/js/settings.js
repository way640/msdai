//Global Parameter for [Google Analytic] Important!
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-44780983-1']);
_gaq.push(['_setDomainName', 'jimu.com']);
_gaq.push(['_setAllowLinker', true]);
_gaq.push(['_trackPageview']);

//Global Parameter for [Agrant Trace] Important!
var _agt = _agt || [];
_agt.push(['_atscu', 'AG_118640_FCTV']);
_agt.push(['_atsdomain', 'jimu.com']);

//Global Parameter for [MediaV] Important!
var _mvq = _mvq || [];
_mvq.push(['$setAccount', 'm-27554-0']);
_mvq.push(['$logConversion']);

//Global Parameter for [Baidu]
var _hmt = _hmt || [];