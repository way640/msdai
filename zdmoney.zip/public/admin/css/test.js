/**
 * Created by chengye on 2017/6/11.
 */
window.loaded = function (){
    document.write('445454545')
}