<?php
/*
*@Use : 活动抽奖
*/
Route::get('home/activity', 'Home\ActivityController@index');


