<?php
/*
*@Use : 借款列表页
*/

Route::get('lenging/lenging', 'Home\LengingController@index');

