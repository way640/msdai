<?php

/*
*@Use : 验证码路由
*/
Route::get('/home/web/StartCaptchaServlet.php', 'UserController@captcha');