<?php
/**
 * 后台登陆.
 */


    Route::any('admin/login/login','Admin\LoginController@login');

