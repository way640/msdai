<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
<!-- 返回顶部调用 begin -->
<div id="mainbody">
  <div class="blogs">
    <div id="index_view">
      <h1 class="c_titile"><?php echo e($info->article_title); ?></h1>
      <p class="box"><?php echo date('Y-m-d H:i:s',$info->article_add_time)?><span>编辑：<?php echo e($info->article_author); ?></span></p>
      <ul>
        <p><?php echo e($info->article_content); ?></p>
      </ul>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Home.title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>