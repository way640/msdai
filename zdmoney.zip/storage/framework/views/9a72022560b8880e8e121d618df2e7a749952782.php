<?php $__env->startSection('content'); ?>
<div class="col-md-12" style=" width: 650px">
<form action="<?php echo e(url('admin/power/store')); ?>" method="post">
    <div class="form-group">
        <?php if(count($errors)>0): ?>
            <div class="mark">
                <?php if(is_object($errors)): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p><?php echo e($errors); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
            <div class="form-group">
                <label class="col-sm-3 control-label">权限列表：</label>
                <div class="col-sm-9">
                    <select class="form-control" style="width: 110px" name="">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($d->priv_id); ?>"><?php echo e($d->_priv_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        <label class="col-sm-3 control-label">权限名称：</label>
        <div class="col-sm-9">
            <input type="text" name="priv_name" class="form-control" placeholder="请输入文本">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">权限控制器：</label>
        <div class="col-sm-9">
            <input type="text" name="priv_controller" class="form-control" placeholder="请输入文本">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">权限行为：</label>
        <div class="col-sm-9">
            <input type="text" name="priv_action" class="form-control" placeholder="请输入文本">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">权限层级：</label>
        <div class="col-sm-9">
            <input type="text" name="priv_level" class="form-control" placeholder="请输入文本">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">pid：</label>
        <div class="col-sm-9">
            <input type="text" name="priv_pid" class="form-control" placeholder="请输入文本">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">	权限描述：</label>
        <div class="col-sm-9">
            <p class="form-control-static"><textarea name="priv_desc" style="width: 435px; height: 50px"></textarea></p>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-3 control-label">权限状态：</label>
        <div class="col-sm-9">
            <label class="radio-inline">
                <input type="radio" checked="" value="1" id="optionsRadios1" name="priv_status">启用</label>
            <label class="radio-inline">
                <input type="radio" value="0" id="optionsRadios2" name="priv_status">未启用</label>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-12 col-sm-offset-3">
            <button class="btn btn-primary" type="submit">保存内容</button>
            <button class="btn btn-white" type="submit">取消</button>
        </div>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>